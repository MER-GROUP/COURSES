x = "hello\nworld"
print(x)

x = r"hello\nworld"  # raw
print(x)